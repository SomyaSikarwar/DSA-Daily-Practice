

public class Main {
    public static void main(String[] args) {
        CardsLogic obj = new CardsLogic();
        obj.logic();
    }
}